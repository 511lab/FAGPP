clc;
clear;

datasets_name={ 'umist','Coil20Data25uni','MnistData05uni','MINIST2k2k','PIE32x32','USPSdatauni'};
tools_name={'FAGPP'};
for ds=1:length(datasets_name)
    file=strcat('D:\soft\matlab\bin\test\AGOP\datasets\',dataset,'.mat');
    load(file);
    for drt=1:length(tools_name)
        tool=tools_name{drt};
        filename=strcat('AGPCA_results\',dataset,"_",tool,"_km.xlsx");
        if exist(filename,'file') 
            
            disp("����");
            continue;
        end
        class=length(unique(Y));
        if size(X,2)>100 %High-dimensional datasets
            data=pca(X,100);
            [n,d]=size(data);
            strat_dim=10;
            step=10;
            end_dim=100;
        else
            data=X;
            [n,d]=size(data);
            strat_dim=1;
            step=1;
            end_dim=d;
        end
        %Parameters
        result=[];
        for dim=strat_dim:step:end_dim
            dataset
            tool
            dim
            %Sampling ratio
            sampRate=5;
            measureCount=20;
            if strcmp(tool,"AGPCA")
                iter=50;
                
                for k=6:1:8
                    for K=2^k-1:1:2^k-1
                        for gamma=[0.001 0.01 1 100 10000]
                            for lemma=[0.001 0.01 1 100 10000]
                                starttime=cputime;
                                [dr_data]=AGPCA(data,dim,iter,gamma,lemma,k,K);
                                runtime=cputime-starttime;
                                dr_data=real(dr_data);
                                [mean_measure,std_measure]=udran_measure(dr_data,Y,sampRate,measureCount);
                                result=[result;mean_measure,dim,K,k,gamma,lemma, runtime,std_measure];
                            end
                        end
                    end
                end  
        xlswrite(filename,result)
    end
end
disp("�����ѱ��棡")

%%
function [mean_measure,std_measure]=udran_measure(data,target,num_samp,iters)
measure=[];
for count=1:iters
    [~,~,idx_train]=Random_sampling(target,num_samp,'class');
    idx_test=setdiff(1:length(target),idx_train);
    mdl=fitcknn(data(idx_train,:),target(idx_train),'NumNeighbors',1,'Distance','euclidean');
    pred_label=predict(mdl,data(idx_test,:));
    [out] = classification_evaluation(target(idx_test)',pred_label');
    measure=[measure;out.avgAccuracy,out.fscoreMacro,out.fscoreMicro];
end
mean_measure=mean(measure,1);
std_measure=std(measure,1);
end